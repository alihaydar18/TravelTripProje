﻿namespace TravelTripProje.Models
{
    public class YorumModel
    {
        public int BlogID { get; set; }
        public string KullaniciAdi { get; set; }
        public string Mail { get; set; }
        public string Yorum { get; set; }
    }
}
